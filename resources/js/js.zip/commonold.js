$( document ).ready(function ()
{
	$(".dropdown").mouseenter(function(e) {
		if(this.menter==1) return;
		console.log(this);
	});

	$(".dropdown").mouseleave(function(e) {
		if(this.menter==0) return;
		this.menter=0;
		console.log(this);
	});


	$(".dropdown > ul.dropdown-menu").mouseenter(function(e) {
		if(this.menter==1) return;
		this.menter=1;
//		console.log(this);
	});

	$(".dropdown > ul.dropdown-menu").mouseleave(function(e) {
		if(this.menter==0) return;
		this.menter=0;
		console.log(this.parent.menter);
	});


	$(".dropdown1" ).click(function(e)
	{
		this.c=10;
		var menu = $(".dropdown");
		if(menu.length > 1)
		{
			var i;
			for(i=0;i<menu.length;i++)
			{
				if( menu[i].c == 10 ) continue;
				var elem = menu[i];
				if( $(elem).hasClass('open') )
				{
					$('> ul.dropdown-menu', elem).stop( true, true ).fadeToggle("fast");
					$(elem).toggleClass('open');
					$('b', elem).toggleClass("caret caret-up");
				}
			}
		}
		this.c=undefined;

//		console.log(menu);
//		var a = $(this).hasClass('open');
//		console.log(a);

		return true;
	});
});
