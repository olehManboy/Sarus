$(document).ready(function () {
    $(".marquee-wrapper").click(function () {
        $(".marquee").toggleClass("mrqstop")
    })
})


