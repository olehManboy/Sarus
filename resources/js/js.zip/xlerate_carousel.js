$(document).ready(function() {
    $("#charts-carousel").slick({
        dots: true,
        arrows: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        adaptativeHeight: true
    })
})