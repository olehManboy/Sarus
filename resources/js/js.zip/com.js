$( document ).ready(function ()
{
	$("#top-menu").jqxMenu({ clickToOpen:false,width:'auto', height: '60', mode: 'horizontal', showTopLevelArrows: true,autoOpen:false});
});
