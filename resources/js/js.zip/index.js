$(document).ready(function () {
    $('.marquee-wrapper').click(function () {
        $('.marquee').toggleClass('mrqstop')
    })
});

let cookieBox = document.querySelector('#cookie-warning-wrapper');// the main cookie warning wrapper
let acceptBtn = document.querySelector('.cookie-btn');// the dismis button
acceptBtn.onclick = () => { //when click on the button
    document.cookie = "cookie=warning; max-age=" + 60 * 60 * 24; // set a cookie
    cookieBox.style.display = 'none' // hide the cookie warning
}
let checkCookie = document.cookie.indexOf("cookie=warning"); //checking our cookie
//if cookie is already set then hide the cookie warning else show it 
checkCookie != -1 ? cookieBox.style.display = "none" : cookieBox.style.display = "block";